package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    // Context and data
    private Context context;
    private List<InventoryItem> itemList;

    // Full unfiltered list kept for search reset
    private List<InventoryItem> fullItemList;

    // Sort state constants
    public static final int SORT_DEFAULT = 0;
    public static final int SORT_NAME_ASC = 1;
    public static final int SORT_NAME_DESC = 2;
    public static final int SORT_QUANTITY_ASC = 3;
    public static final int SORT_QUANTITY_DESC = 4;

    // Current sort state
    private int currentSortState = SORT_DEFAULT;

    // Listener interface for delete and update actions
    public interface OnItemActionListener {
        void onDeleteClick(int itemId, int position);
        void onQuantityChange(int itemId, int newQuantity, int position);
    }

    private OnItemActionListener listener;

    public InventoryAdapter(Context context, List<InventoryItem> itemList, OnItemActionListener listener) {
        this.context = context;
        this.itemList = itemList;
        this.fullItemList = new ArrayList<>(itemList);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout for each row
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the current item
        InventoryItem item = itemList.get(position);

        // Set item name and quantity
        holder.textItemName.setText(item.getItemName());
        holder.textItemQuantity.setText(String.valueOf(item.getQuantity()));

        // Handle increase button click
        holder.buttonIncrease.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            listener.onQuantityChange(item.getId(), newQuantity, holder.getAdapterPosition());
        });

        // Handle decrease button click
        holder.buttonDecrease.setOnClickListener(v -> {
            int currentQuantity = item.getQuantity();
            // Prevent quantity from going below zero
            if (currentQuantity > 0) {
                int newQuantity = currentQuantity - 1;
                listener.onQuantityChange(item.getId(), newQuantity, holder.getAdapterPosition());
            }
        });

        // Handle delete button click
        holder.buttonDeleteItem.setOnClickListener(v -> {
            listener.onDeleteClick(item.getId(), holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Refresh the full list when database reloads
    public void refreshFullList() {
        fullItemList = new ArrayList<>(itemList);
    }

    // Filter items by search query against the full list
    public void filter(String query) {
        String lowerQuery = query.toLowerCase().trim();
        itemList.clear();
        if (lowerQuery.isEmpty()) {
            itemList.addAll(fullItemList);
        } else {
            for (InventoryItem item : fullItemList) {
                if (item.getItemName().toLowerCase().contains(lowerQuery)) {
                    itemList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    // Cycle through sort states
    public int cycleSortState() {
        currentSortState = (currentSortState + 1) % 5;
        applySortToItemList();
        return currentSortState;
    }

    // Apply current sort to the itemList
    private void applySortToItemList() {
        switch (currentSortState) {
            case SORT_NAME_ASC:
                Collections.sort(itemList, (a, b) -> a.getItemName().compareToIgnoreCase(b.getItemName()));
                break;
            case SORT_NAME_DESC:
                Collections.sort(itemList, (a, b) -> b.getItemName().compareToIgnoreCase(a.getItemName()));
                break;
            case SORT_QUANTITY_ASC:
                Collections.sort(itemList, (a, b) -> Integer.compare(a.getQuantity(), b.getQuantity()));
                break;
            case SORT_QUANTITY_DESC:
                Collections.sort(itemList, (a, b) -> Integer.compare(b.getQuantity(), a.getQuantity()));
                break;
            default:
                itemList.clear();
                itemList.addAll(fullItemList);
                break;
        }
        notifyDataSetChanged();
    }

    // ViewHolder class holds references to each view in the row
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName;
        TextView textItemQuantity;
        Button buttonIncrease;
        Button buttonDecrease;
        Button buttonDeleteItem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textItemQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonDeleteItem = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
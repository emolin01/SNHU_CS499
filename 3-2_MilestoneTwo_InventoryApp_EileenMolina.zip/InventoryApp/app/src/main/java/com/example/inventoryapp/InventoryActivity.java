package com.example.inventoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends Activity implements InventoryAdapter.OnItemActionListener {

    // UI elements
    private RecyclerView recyclerViewInventory;
    private Button buttonAddItem;
    private Button buttonSmsSettings;

    // Database and adapter
    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private List<InventoryItem> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Connect UI elements to code
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Set up RecyclerView
        itemList = new ArrayList<>();
        adapter = new InventoryAdapter(this, itemList, this);
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewInventory.setAdapter(adapter);

        // Load inventory items from database
        loadInventoryItems();

        // Navigate to Add Item screen when Add Item is clicked
        buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivityForResult(intent, 1);
        });

        // Navigate to SMS Settings screen when SMS Settings is clicked
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    // Load all inventory items from database and display in RecyclerView
    private void loadInventoryItems() {
        itemList.clear();
        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int quantity = cursor.getInt(2);
                itemList.add(new InventoryItem(id, itemName, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    // Refresh inventory list when returning from Add Item screen
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            loadInventoryItems();
        }
    }

    // Handle delete button click from adapter
    @Override
    public void onDeleteClick(int itemId, int position) {
        if (databaseHelper.deleteItem(itemId)) {
            itemList.remove(position);
            adapter.notifyItemRemoved(position);
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle quantity change from adapter
    @Override
    public void onQuantityChange(int itemId, int newQuantity, int position) {
        if (databaseHelper.updateItemQuantity(itemId, newQuantity)) {
            itemList.get(position).setQuantity(newQuantity);
            adapter.notifyItemChanged(position);

            // Notify user if quantity reaches zero
            if (newQuantity == 0) {
                Toast.makeText(this, "Warning: Item quantity has reached zero!", Toast.LENGTH_LONG).show();
            }
        }
    }
}
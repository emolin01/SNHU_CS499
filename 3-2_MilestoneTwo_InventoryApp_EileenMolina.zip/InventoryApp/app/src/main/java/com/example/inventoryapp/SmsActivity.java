package com.example.inventoryapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends Activity {

    // Permission request code
    private static final int SMS_PERMISSION_CODE = 100;

    // UI elements
    private Button buttonGrantPermission;
    private Button buttonDeny;
    private TextView textSmsResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Connect UI elements to code
        buttonGrantPermission = findViewById(R.id.buttonGrantPermission);
        buttonDeny = findViewById(R.id.buttonDeny);
        textSmsResponse = findViewById(R.id.textSmsResponse);

        // Handle grant permission button click
        buttonGrantPermission.setOnClickListener(v -> {
            // Check if permission is already granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                textSmsResponse.setText("SMS notifications enabled. You will be notified when inventory reaches zero.");
            } else {
                // Request permission from user
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        });

        // Handle deny button click
        buttonDeny.setOnClickListener(v -> {
            // App continues to function without SMS notifications
            textSmsResponse.setText("SMS notifications disabled. The app will continue to function without notifications.");
        });
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                textSmsResponse.setText("SMS notifications enabled. You will be notified when inventory reaches zero.");
            } else {
                // Permission denied
                textSmsResponse.setText("SMS notifications disabled. The app will continue to function without notifications.");
            }
        }
    }
}
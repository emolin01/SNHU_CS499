package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    // Context and data
    private Context context;
    private List<InventoryItem> itemList;

    // Listener interface for delete and update actions
    public interface OnItemActionListener {
        void onDeleteClick(int itemId, int position);
        void onQuantityChange(int itemId, int newQuantity, int position);
    }

    private OnItemActionListener listener;

    public InventoryAdapter(Context context, List<InventoryItem> itemList, OnItemActionListener listener) {
        this.context = context;
        this.itemList = itemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout for each row
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the current item
        InventoryItem item = itemList.get(position);

        // Set item name and quantity
        holder.textItemName.setText(item.getItemName());
        holder.textItemQuantity.setText(String.valueOf(item.getQuantity()));

        // Handle increase button click
        holder.buttonIncrease.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            listener.onQuantityChange(item.getId(), newQuantity, holder.getAdapterPosition());
        });

        // Handle decrease button click
        holder.buttonDecrease.setOnClickListener(v -> {
            int currentQuantity = item.getQuantity();
            // Prevent quantity from going below zero
            if (currentQuantity > 0) {
                int newQuantity = currentQuantity - 1;
                listener.onQuantityChange(item.getId(), newQuantity, holder.getAdapterPosition());
            }
        });

        // Handle delete button click
        holder.buttonDeleteItem.setOnClickListener(v -> {
            listener.onDeleteClick(item.getId(), holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // ViewHolder class holds references to each view in the row
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName;
        TextView textItemQuantity;
        Button buttonIncrease;
        Button buttonDecrease;
        Button buttonDeleteItem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textItemQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonDeleteItem = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
package com.example.inventoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity {

    // UI elements
    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;
    private Button buttonTogglePassword;

    // Database helper
    private DatabaseHelper databaseHelper;

    // Track password visibility state
    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Connect UI elements to code
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);
        buttonTogglePassword = findViewById(R.id.buttonTogglePassword);

        // Handle password visibility toggle
        buttonTogglePassword.setOnClickListener(v -> togglePasswordVisibility());

        // Handle login button click
        buttonLogin.setOnClickListener(v -> handleLogin());

        // Handle create account button click
        buttonCreateAccount.setOnClickListener(v -> handleCreateAccount());
    }

    // Toggle password field between visible and hidden
    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            // Hide password
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            buttonTogglePassword.setText("Show");
            isPasswordVisible = false;
        } else {
            // Show password
            editTextPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            buttonTogglePassword.setText("Hide");
            isPasswordVisible = true;
        }
        // Move cursor to end of text after toggling
        editTextPassword.setSelection(editTextPassword.getText().length());
    }

    // Validate username and password input
    private boolean validateInput(String username, String password) {
        // Check for empty fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Check that username is not only whitespace
        if (username.trim().isEmpty()) {
            Toast.makeText(this, "Username cannot be blank", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Enforce minimum password length
        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    // Handle login logic separated from UI
    private void handleLogin() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Validate input before checking database
        if (!validateInput(username, password)) {
            return;
        }

        // Check credentials against database
        if (databaseHelper.checkUser(username, password)) {
            // Navigate to inventory screen on success
            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle account creation logic separated from UI
    private void handleCreateAccount() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Validate input before adding to database
        if (!validateInput(username, password)) {
            return;
        }

        // Add new user to database
        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            // Navigate to inventory screen after account creation
            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
        }
    }
}
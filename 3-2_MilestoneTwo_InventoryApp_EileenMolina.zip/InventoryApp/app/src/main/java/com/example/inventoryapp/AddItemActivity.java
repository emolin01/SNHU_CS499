package com.example.inventoryapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends Activity {

    // UI elements
    private EditText editTextItemName;
    private EditText editTextQuantity;
    private Button buttonSave;
    private Button buttonCancel;

    // Database helper
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Connect UI elements to code
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        buttonSave = findViewById(R.id.buttonSave);
        buttonCancel = findViewById(R.id.buttonCancel);

        // Handle save button click
        buttonSave.setOnClickListener(v -> {
            String itemName = editTextItemName.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();

            // Validate that fields are not empty
            if (itemName.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Parse quantity as integer
            int quantity = Integer.parseInt(quantityStr);

            // Add item to database
            if (databaseHelper.addItem(itemName, quantity)) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                // Return to inventory screen
                setResult(Activity.RESULT_OK);
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle cancel button click
        buttonCancel.setOnClickListener(v -> {
            // Return to inventory screen without saving
            finish();
        });
    }
}